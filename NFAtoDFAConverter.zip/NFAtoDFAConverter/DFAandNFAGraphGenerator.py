#Author: Fung Sim Leung 40195538

# noinspection PyUnresolvedReferences
import graphviz
# noinspection PyUnresolvedReferences
from PySimpleAutomata import automata_IO
# noinspection PyUnresolvedReferences
import pydot

# A welcoming message

print("Welcome to the DFA and NFA generator program.")
print("Importing tha DFA_input.txt file for input...")

which_question = "0"
while which_question != "1" and which_question != "2":
    print('Enter \'1\' if you want to print the DFA/NFA diagram, or \'2\' if you want to convert an NFA to a DFA.')
    which_question = input()
    if which_question != "1" and which_question != "2":
        print("Invalid input. Please try again.")

# Build a DFA/NFA dictionary in a json format by reading an external text file for inout

DFA = {
    "alphabet": [],
    "states": [],
    "initial_state": [],
    "accepting_states": [],
    "transitions": {}
}

transitions_outsideDic = []
# DFA["transitions"] = OrderedDict()
# print(DFA)
with open("DFA_input.txt") as DFA_input:
    alphabet_input = DFA_input.readline()

    DFA["alphabet"] = alphabet_input[:len(alphabet_input) - 1].split(",")
    states_input = DFA_input.readline()
    DFA["states"] = states_input[:len(states_input) - 1].split(",")
    initial_state_input = DFA_input.readline()
    DFA["initial_state"] = initial_state_input[:len(initial_state_input) - 1]
    accepting_states_input = DFA_input.readline()
    DFA["accepting_states"] = accepting_states_input[:len(accepting_states_input) - 1].split(",")
    transition_input = DFA_input.readline()

    while (transition_input != ''):
        if (transition_input[len(transition_input) - 1] == "\n"):
            temp_holder_for_transition = transition_input[:len(transition_input) - 1].split(",")
        else:
            temp_holder_for_transition = transition_input.split(",")
        # the tuple will have 3 elements because an NFA may have the same first 2 elements with different transitions.
        # Adding the third element to the tuple will make sure each tuple is unique
        # and the dictionary will not erase the duplicated tuples.
        temp_list = (temp_holder_for_transition[0], temp_holder_for_transition[1], temp_holder_for_transition[2])

        transitions_outsideDic.append(temp_list)
        if (temp_holder_for_transition[2] != "nowhere"):
            DFA["transitions"][temp_list] = temp_holder_for_transition[2]
            # else:
            #   DFA["transitions"][temp_list] += temp_holder_for_transition[2]
        # else:
        # DFA["transitions"][temp_list] = "∅"
        transition_input = DFA_input.readline()

# The powerset function is used for Question 2 (converting an NFA to a DFA)
# because we need to find all the combinations of states.

def powerset(states_list):
    all_state_combos = [[]]
    for state in states_list:
        for combo in all_state_combos:
            all_state_combos = all_state_combos + [combo + [state]]

    # To remove brackets and quotation marks within sub-lists
    all_state_combos_processed = []
    temp_string = ''
    for i in range(len(all_state_combos)):
        for j in range (len(all_state_combos[i])):
            all_state_combos_processed.append(', '.join(all_state_combos[i]) )
    return all_state_combos

# This function builds a NFAtoDFA dictionary.
# It begins with importing values from the DFA dictionary.
# And then the function will generate all the remaining states and transitions for a complete DFA graph and table.
def convertNFAtoDFA(DFA, transitions_outsideDic):
    all_state_combos = powerset(DFA["states"])
    NFAtoDFA = {"alphabet": DFA["alphabet"], "states": [], "initial_state": DFA["initial_state"],
                "accepting_states": [], "transitions": {}}
    NFAtoDFA_transitionsOutsideDic = []  # for the table only

    # The first "transition" on the table is always null pointing to null.

    counter = 0
    while counter < len(all_state_combos):
        if len(all_state_combos[counter]) == 0:
            for letter in NFAtoDFA["alphabet"]:
                temp_holder = ["∅", letter, "∅"]
                NFAtoDFA_transitionsOutsideDic.append(temp_holder)
                # all_state_combos.pop(counter)
        counter += 1

    # Rearrange the power sets within the list in an ascending order

    number_of_states_in_the_field = 1
    while number_of_states_in_the_field <= len(DFA["states"]):
        for state in DFA["states"]:
            index = 0
            while index < len(all_state_combos):
                if (len(all_state_combos[index]) == number_of_states_in_the_field) and (
                        all_state_combos[index][0] == state):
                    NFAtoDFA["states"] = NFAtoDFA["states"] + [all_state_combos[index]]
                    for k in range(len(all_state_combos[index])):
                        if all_state_combos[index][k] in DFA["accepting_states"]:

                            NFAtoDFA["accepting_states"] = NFAtoDFA["accepting_states"] + [all_state_combos[index]]

                index += 1
        number_of_states_in_the_field += 1

    # To generate all of the transitions in the table

    NFAtoDFA_all_directions = []
    for m in range(len(NFAtoDFA["states"])):
        for letter in NFAtoDFA["alphabet"]:
            isNowhere = True
            addToList = False
            for p in range(len(NFAtoDFA["states"][m])):
                for r in range(len(transitions_outsideDic)):
                    if (NFAtoDFA["states"][m][p] == transitions_outsideDic[r][0]):
                        if transitions_outsideDic[r][1] == letter and transitions_outsideDic[r][2] == "nowhere":
                            hasNoWhere = True
                            addToList = True
                        elif transitions_outsideDic[r][1] == letter and transitions_outsideDic[r][2] != "nowhere":
                            NFAtoDFA_all_directions.append(transitions_outsideDic[r][2])
                            isNowhere = False
                            addToList = True

            temp_string = ', '.join(NFAtoDFA["states"][m])

            if isNowhere and addToList:

                temp_holder = [temp_string, letter, "∅"]
                NFAtoDFA_transitionsOutsideDic.append(temp_holder)
            elif addToList:
                temp_holder = [temp_string, letter, ', '.join(NFAtoDFA_all_directions)]
                NFAtoDFA_transitionsOutsideDic.append(temp_holder)

            NFAtoDFA_all_directions = []

    # To generate the DFA transitions for the graph. Not all transitions in the table are shown in the graph.

    NFAtoDFA_transitionsOutsideDic, NFAtoDFA = get_all_transitions_of_a_state(NFAtoDFA_transitionsOutsideDic, NFAtoDFA, NFAtoDFA["initial_state"])

    # Clear the brackets and quotation marks in sub-lists in the NFAtoDFA dictionary

    states_no_formatting = []
    for a in range(len(NFAtoDFA["states"])):
        states_no_formatting.append(', '.join(NFAtoDFA["states"][a]))

    NFAtoDFA["statesForTable"] = states_no_formatting

    key_list_transitions = list(NFAtoDFA["transitions"].keys())
    states_in_graph_no_formatting = []

    for b in range(len(states_no_formatting)):
        alreadySaved = False
        for c in range(len(key_list_transitions)):
            if states_no_formatting[b] == key_list_transitions[c][0] and alreadySaved == False :
                states_in_graph_no_formatting.append(states_no_formatting[b])
                alreadySaved = True

    NFAtoDFA["states"] = states_in_graph_no_formatting


    accepting_states_no_formatting = []
    for d in range(len(NFAtoDFA["accepting_states"])):
        accepting_states_no_formatting.append(', '.join(NFAtoDFA["accepting_states"][d]))

    NFAtoDFA["accepting_states"] = accepting_states_no_formatting

    return NFAtoDFA, NFAtoDFA_transitionsOutsideDic

# This is a recursive function to generate all the transitions for the NFAtoDFA graph.

def get_all_transitions_of_a_state(NFAtoDFA_transitionsOutsideDic, NFAtoDFA, a_state):

    how_many_keys_stored = len(NFAtoDFA["transitions"].keys())

    for letter in NFAtoDFA["alphabet"]:
        for index4 in range(len(NFAtoDFA_transitionsOutsideDic)):
            if (NFAtoDFA_transitionsOutsideDic[index4][0]) == a_state and \
                    NFAtoDFA_transitionsOutsideDic[index4][1] == letter:
                if NFAtoDFA_transitionsOutsideDic[index4][2] != "∅":

                    temp_holder = (NFAtoDFA_transitionsOutsideDic[index4][0], NFAtoDFA_transitionsOutsideDic[index4][1], NFAtoDFA_transitionsOutsideDic[index4][2])
                    NFAtoDFA["transitions"][temp_holder] = NFAtoDFA_transitionsOutsideDic[index4][2]
                    how_many_keys_stored += 1

                    key_list = list(NFAtoDFA["transitions"].keys())

                    toContinue = True

                else:
                    temp_holder = (NFAtoDFA_transitionsOutsideDic[index4][0], NFAtoDFA_transitionsOutsideDic[index4][1], "∅")
                    NFAtoDFA["transitions"][temp_holder] = "trap"
                    how_many_keys_stored += 1

                    key_list = list(NFAtoDFA["transitions"].keys())

                    toContinue = True



                for d in range(len(NFAtoDFA["transitions"])):
                    if NFAtoDFA_transitionsOutsideDic[index4][2] in key_list[d][0] or NFAtoDFA_transitionsOutsideDic[index4][2] == "∅":
                        toContinue = False
                if toContinue:
                    NFAtoDFA_transitionsOutsideDic, NFAtoDFA = get_all_transitions_of_a_state(NFAtoDFA_transitionsOutsideDic, NFAtoDFA, NFAtoDFA_transitionsOutsideDic[index4][2])

    return NFAtoDFA_transitionsOutsideDic, NFAtoDFA


# This function prints the table of a DFA/NFA table and graph without conversion (for Question 1).
def question1 (DFA,transitions_outsideDic):
    print("                         ", end="")
    for letter in DFA["alphabet"]:
        print("|" + "{0:^24}".format(letter), end="")

    print()
    print("-------------------------", end = "")
    for how_many_letters in range(len(DFA["alphabet"])):
        print("-------------------------", end = "")
    print()

    state_output_in_table = ""
    for state in DFA["states"]:

        # print("\t\t", end="")
        if state in DFA["initial_state"]:
            state_output_in_table += "->"
            #print("->", end="")
        if state in DFA["accepting_states"]:
            state_output_in_table += "*"
            # print("*", end="")
        state_output_in_table += "{" + str(state) + "}"
        print("{0:^25}".format(state_output_in_table), end="")
        state_output_in_table = ""

        for letter2 in DFA["alphabet"]:
            all_directions = []
            for index in range(len(transitions_outsideDic) - 1):
                one_transition = transitions_outsideDic[index]
                # print(state, "  ", letter2, " transition: " , one_transition)
                if (one_transition[0] == state) and (one_transition[1] == letter2):
                    all_directions.append(one_transition[2])
            hasNowhere = False
            isNowhere = True
            index_that_contains_nowhere = []
            for index2 in range(len(all_directions)):
                if all_directions[index2] != "nowhere":
                    isNowhere = False
                else:
                    hasNowhere = True
                    index_that_contains_nowhere.append(index2)

            if isNowhere:
                all_directions = "∅"
                transition_output_in_table = "∅"
            else:
                if hasNowhere:
                    for index3 in range(len(index_that_contains_nowhere) - 1, -1, -1):
                        all_directions.pop(index_that_contains_nowhere[index3])

            if not isNowhere:
                transition_output_in_table = "{" + ', '.join(all_directions) + "}"

            print("|", end="")

            print("{0:^24}".format(transition_output_in_table), end="")

        print()

# This function prints the table of a NFAtoDFA table and graph with conversion (for Question 2).


def question2 (NFAtoDFA,NFAtoDFA_transitionsOutsideDic):
    print("                         ", end="")
    for letter in NFAtoDFA["alphabet"]:
        print("|" + "{0:^24}".format(letter), end="")

    print()
    print("-------------------------", end = "")
    for how_many_letters in range(len(NFAtoDFA["alphabet"])):
        print("-------------------------", end = "")
    print()

    # to print the first row for the ∅ node

    state_output_in_table = "∅"
    print("{0:^25}".format(state_output_in_table), end="")

    state_output_in_table = ""

    for letter2 in NFAtoDFA["alphabet"]:
        all_directions = ""
        for i in range(len(NFAtoDFA_transitionsOutsideDic)):
            if NFAtoDFA_transitionsOutsideDic[i][0] == "∅" and NFAtoDFA_transitionsOutsideDic[i][1] == letter2:
                all_directions = NFAtoDFA_transitionsOutsideDic[i][2]
        transition_output_in_table = str(all_directions)
        print("|", end="")
        print("{0:^25}".format(transition_output_in_table), end="")
    print()

    # to print the remaining rows of the table

    for state in NFAtoDFA["statesForTable"]:
        if state in NFAtoDFA["initial_state"]:
            state_output_in_table = state_output_in_table + "->"
        if state in NFAtoDFA["accepting_states"]:
            state_output_in_table = state_output_in_table + "*"
        state_output_in_table = state_output_in_table + "{" + str(state) + "}"
        print("{0:^25}".format(state_output_in_table), end="")
        state_output_in_table = ""
        for letter2 in NFAtoDFA["alphabet"]:

            all_directions = ""
            for i in range(len(NFAtoDFA_transitionsOutsideDic)):
                if NFAtoDFA_transitionsOutsideDic[i][0] == state and NFAtoDFA_transitionsOutsideDic[i][1] == letter2:
                    all_directions = NFAtoDFA_transitionsOutsideDic[i][2]
            if all_directions == "∅":
                transition_output_in_table = str(all_directions)
            else:
                transition_output_in_table = "{" + str(all_directions) + "}"
            print("|", end="")
            print("{0:^25}".format(transition_output_in_table), end="")

        print()

if which_question == "1":
    print("The table without conversion:")
    question1(DFA, transitions_outsideDic)
    automata_IO.dfa_to_dot(DFA, 'noConversion', './')
    print()
    print("Open the file noConversion.dot.svg in the folder ./for the graph!")

else:
    print("Converting an NFA to a DFA... ")
    NFAtoDFA, NFAtoDFA_transitionsOutsideDic = convertNFAtoDFA(DFA, transitions_outsideDic)
    question2(NFAtoDFA, NFAtoDFA_transitionsOutsideDic)
    automata_IO.dfa_to_dot(NFAtoDFA, 'NFAtoDFA', './')
    print()
    print("Open the file NFAtoDFA.dot.svg in the folder for the graph!")


